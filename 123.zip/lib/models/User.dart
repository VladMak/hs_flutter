class User{

  static bool loggedIn = false;
  static String username = "Гость";
}