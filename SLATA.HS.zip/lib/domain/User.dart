class User {
    late String Token;
    late String Id;
    late String Name;
    late String Card;
    late String Email;
    late String Password;
    late String Enter;
    late String UserToken;
    late int Level;
    late int NextLevel;
    late double SumShop;   
}
