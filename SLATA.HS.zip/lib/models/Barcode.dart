import 'package:barcode/barcode.dart';

class BarcodeGenerator {
  void gen() {
    var dm = Barcode.dataMatrix();
  }
}
